package ShituMonSha;

public class Pure {
    
    public static void main(String args[]){

        FreeDialFactory beFree = new FreeDialFactory();
        beFree.create().CallFreeDial();
    }
}
