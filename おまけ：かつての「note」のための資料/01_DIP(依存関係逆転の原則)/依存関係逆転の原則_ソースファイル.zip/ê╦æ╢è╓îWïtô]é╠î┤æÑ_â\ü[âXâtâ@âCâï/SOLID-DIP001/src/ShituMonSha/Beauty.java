package ShituMonSha;

public class Beauty {
    
    public static void main(String args[]){

        FreeDialFactory beFree = new FreeDialFactory();
        beFree.create().CallFreeDial();
    }
}
