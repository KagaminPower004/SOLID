package ShituMonSha;
import KaitouSha.CallCenter;

public class FreeDialFactory {
    public FreeDial create(){
        return new CallCenter();

    }
}
