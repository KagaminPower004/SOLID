package ShituMonSha;
import KaitouSha.ContactCenter;

public class FreeDialFactory {
    public FreeDial create(){
        return new ContactCenter();

    }
}
