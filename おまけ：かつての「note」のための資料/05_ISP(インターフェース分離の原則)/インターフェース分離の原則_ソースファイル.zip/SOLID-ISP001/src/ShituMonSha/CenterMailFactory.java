package ShituMonSha;
import KaitouSha.*;

public class CenterMailFactory {
    public CenterMail create(){
        return new ContactCenter();

    }
}
