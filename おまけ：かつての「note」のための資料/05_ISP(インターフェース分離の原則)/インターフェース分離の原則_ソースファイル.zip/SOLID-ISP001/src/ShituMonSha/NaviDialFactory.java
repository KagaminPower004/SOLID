package ShituMonSha;
import KaitouSha.*;

public class NaviDialFactory {
    public NaviDial create(){
        return new ContactCenter();

    }
}
