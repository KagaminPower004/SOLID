package ShituMonSha;
import KaitouSha.*;

public class FreeDialFactory {
    public FreeDial create(){
        return new ContactCenter();

    }
}
