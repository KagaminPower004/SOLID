package ShituMonSha;

public interface NaviDial {
    public void FaxNaviDial();
}
