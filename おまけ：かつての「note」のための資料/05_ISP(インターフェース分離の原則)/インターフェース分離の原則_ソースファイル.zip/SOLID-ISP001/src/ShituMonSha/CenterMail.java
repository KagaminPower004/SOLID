package ShituMonSha;

public interface CenterMail {
    public void SecureMail();
}
