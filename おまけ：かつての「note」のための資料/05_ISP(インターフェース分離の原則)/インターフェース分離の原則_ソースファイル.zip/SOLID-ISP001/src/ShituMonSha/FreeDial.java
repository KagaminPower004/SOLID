package ShituMonSha;

public interface FreeDial {
    public void CallFreeDial();
}
