package ShituMonSha;

public interface SupportService {
    public void CallFreeDial();
    public void FaxNaviDial();
    public void SecureMail();
}
