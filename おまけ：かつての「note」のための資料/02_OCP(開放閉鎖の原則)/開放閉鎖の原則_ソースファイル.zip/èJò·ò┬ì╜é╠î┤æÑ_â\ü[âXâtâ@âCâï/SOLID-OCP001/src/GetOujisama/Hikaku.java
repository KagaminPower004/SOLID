package GetOujisama;

public interface Hikaku {
    public String compare(Oujisama o1,Oujisama o2);
}
