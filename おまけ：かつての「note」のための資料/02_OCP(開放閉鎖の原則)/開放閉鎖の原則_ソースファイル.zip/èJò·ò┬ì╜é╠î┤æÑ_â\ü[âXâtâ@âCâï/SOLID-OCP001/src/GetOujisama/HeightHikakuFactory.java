package GetOujisama;
import HikakuOujisama.*;

public class HeightHikakuFactory {
    public Hikaku create(){
    	
    	return new HeightHikaku();
       
    }
}
