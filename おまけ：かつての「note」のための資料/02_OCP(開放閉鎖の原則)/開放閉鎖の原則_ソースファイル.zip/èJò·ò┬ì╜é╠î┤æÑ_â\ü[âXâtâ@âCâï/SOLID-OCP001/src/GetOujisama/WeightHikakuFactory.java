package GetOujisama;
import HikakuOujisama.*;

public class WeightHikakuFactory {
    public Hikaku create(){
  	
    	return new WeightHikaku();
      
    }
}
