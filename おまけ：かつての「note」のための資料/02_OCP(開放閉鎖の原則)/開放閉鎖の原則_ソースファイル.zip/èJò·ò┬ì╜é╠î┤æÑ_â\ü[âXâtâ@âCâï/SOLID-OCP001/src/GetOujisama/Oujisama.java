package GetOujisama;

public interface Oujisama {
    public abstract String getName();
    public abstract int getHeight();
    public abstract int getWeight();
    public abstract int getAge();
}
