package User;

import Dao.Iterator;

public interface Aggregate {
    public Iterator iterator();
}
