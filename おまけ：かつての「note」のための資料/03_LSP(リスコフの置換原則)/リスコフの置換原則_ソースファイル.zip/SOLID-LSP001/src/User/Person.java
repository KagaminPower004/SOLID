package User;

public interface Person { 
    public String getName();
    public String getphone_number();
}
