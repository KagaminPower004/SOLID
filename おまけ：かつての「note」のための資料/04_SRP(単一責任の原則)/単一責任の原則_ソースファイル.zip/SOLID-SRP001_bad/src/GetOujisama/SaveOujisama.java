package GetOujisama;

public interface SaveOujisama {
    public void save(Oujisama o);
}
