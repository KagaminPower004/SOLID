package GetOujisama;

public interface SaveOujisama {
    public void save(String o);
}
