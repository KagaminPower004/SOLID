package WriteUser;

public interface Person { 
    public String getName();
    public String getPhone_number();
    public String getAddress();
}
