package WriteUser;

public interface SaveKokyakuDaityo{
    public void save(Person Person);

}
