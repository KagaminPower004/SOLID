package ReadUser;

public interface KeyPuncher{
    public void registKokyakuDaityo();

}
