package ReadUser;

public interface ReadKokyakuDaityo{
    public void Read();

}
